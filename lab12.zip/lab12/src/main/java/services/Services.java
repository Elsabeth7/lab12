package services;

public class Services {
    public static ProductService PRODUCT_SERVICE = new ProductServiceImpl();
    public static AuthService AUTHENTICATION_SERVICE = new AuthServiceImpl();
}
